    </div>
    <footer class="container-fluid bg-light border-top">
        <p class="text-center text-dark">Copyright &copy; <?php echo date("Y") ?> All Rights Reserved.</p>
    </footer>
</body>
</html>
