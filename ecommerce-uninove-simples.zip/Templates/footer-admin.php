    </div>
    <footer class="container-fluid bg-dark">
        <p class="text-center text-light">Copyright (c) <?php echo date("Y") ?> All Rights Reserved.</p>
    </footer>
</body>
</html>
