<?php
$host = "localhost";
$user = "root";
$pass = "q1w2e3r4";
$database = "lojauninove";
$conexao = mysqli_connect($host, $user, $pass, $database) or die(mysqli_error());
