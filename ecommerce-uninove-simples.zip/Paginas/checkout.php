<?php
    require_once "../Controller/PageController.php";
    $controller = new \Controller\PageController();
    $controller->checkout();