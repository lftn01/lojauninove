<?php include "../../Templates/header-admin.php"?>
categorias
<?php include "../../Templates/footer-admin.php"?>
