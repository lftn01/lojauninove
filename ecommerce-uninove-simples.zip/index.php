<!-- Arquivo inicial não ha qualquer interação, mas não deve-se deletar o mesmo -->
<?php
header("Location: Paginas/home.php");
